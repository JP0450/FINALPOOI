﻿using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Text;
using Final_proyecto.Data;
using Microsoft.EntityFrameworkCore;
using Final_proyecto.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Identity.Data;
using System.Net.Mail;
using System.Net;

namespace Final_proyecto.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly EmailService _emailService;
        private readonly IConfiguration _configuration;


        public static Dictionary<string, string> codigosVerificacion = new Dictionary<string, string>();


        public LoginController(ApplicationDbContext context, EmailService emailService, IConfiguration configuration)
        {
            _context = context;
            _emailService = emailService;
            _configuration = configuration;
        }
        //peticiones
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Final_proyecto.Models.LoginRequest request)
        {
            var usuario = await _context.Clientes
                .FirstOrDefaultAsync(c => c.Email == request.email);

            if (usuario == null || usuario.Contraseña != request.contrasena)
                return Unauthorized("Credenciales incorrectas");

            var token = GenerarToken(usuario.Email, usuario.Rol, usuario.Id);

            return Ok(new { token = token, rol = usuario.Rol, clienteId = usuario.Id });

        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Final_proyecto.Models.RegisterRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Contraseña))
                return BadRequest("Email y contraseña son requeridos");

            // Validar código de verificación
            if (!codigosVerificacion.TryGetValue(request.Email, out var codigoGuardado) || request.CodigoVerificacion != codigoGuardado)
                return BadRequest("Código de verificación incorrecto o no proporcionado");

            if (await _context.Clientes.AnyAsync(c => c.Email == request.Email))
                return BadRequest("El correo ya está registrado");

            var nuevoCliente = new Clientes
            {
                Email = request.Email,
                Contraseña = request.Contraseña,
                Rol = "Comprador" // Siempre será comprador
            };

            _context.Clientes.Add(nuevoCliente);
            await _context.SaveChangesAsync();

            // Eliminar código usado
            codigosVerificacion.Remove(request.Email);

            return Ok("Cuenta creada con éxito");
        }

        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] Final_proyecto.Models.ResetPasswordRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.NewPassword))
                return BadRequest("Email y nueva contraseña son requeridos");

            // Validar código de verificación
            if (!codigosVerificacion.TryGetValue(request.Email, out var codigoGuardado) || request.CodigoVerificacion != codigoGuardado)
                return BadRequest("Código de verificación incorrecto o no proporcionado");

            var usuario = await _context.Clientes.FirstOrDefaultAsync(c => c.Email == request.Email);

            if (usuario == null)
                return NotFound("Usuario no encontrado");

            usuario.Contraseña = request.NewPassword;
            await _context.SaveChangesAsync();

            // Eliminar código usado
            codigosVerificacion.Remove(request.Email);

            return Ok("Contraseña actualizada exitosamente");
        }

        //peticiones

        /// para verificar el codigo de verificacion
        [HttpPost("enviar-codigo")]
        public async Task<IActionResult> EnviarCodigoVerificacion([FromBody] EmailRequest request)
        {
            var email = request.Email;

            if (string.IsNullOrWhiteSpace(email))
                return BadRequest("El email es requerido");

            var codigo = new Random().Next(100000, 999999).ToString();

            codigosVerificacion[email] = codigo;

            string asunto = "Código de verificación";
            string cuerpo = $"<h2>Tu código es: {codigo}</h2>";

            await _emailService.SendEmailAsync(email, asunto, cuerpo);

            return Ok("Código enviado");
        }


        ////metodo para enviar el correo
        //public async Task SendEmailAsync(string toEmail, string subject, string body)
        //{
        //    try
        //    {
        //        var smtpSettings = _config.GetSection("SmtpSettings");

        //        var client = new SmtpClient(smtpSettings["Server"], int.Parse(smtpSettings["Port"]))
        //        {
        //            Credentials = new NetworkCredential(smtpSettings["Username"], smtpSettings["Password"]),
        //            EnableSsl = true
        //        };

        //        var mail = new MailMessage
        //        {
        //            From = new MailAddress(smtpSettings["SenderEmail"], smtpSettings["SenderName"]),
        //            Subject = subject,
        //            Body = body,
        //            IsBodyHtml = true
        //        };

        //        mail.To.Add(toEmail);

        //        await client.SendMailAsync(mail);
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine($"Error al enviar correo: {ex.Message}");
        //        throw;
        //    }
        //}

        ////



        //metodo para generar el token(deberiar ir en modelos o en user_yonoseque para buenas practicas)
        private string GenerarToken(string email, string rol, int clienteId)
        {
            var secretKey = _configuration.GetSection("Jwt").GetValue<string>("Key");
            var key = Encoding.UTF8.GetBytes(secretKey);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
            new Claim(ClaimTypes.Name, email),
            new Claim(ClaimTypes.Role, rol),
            new Claim("ClienteId", clienteId.ToString())


        }),
                Expires = DateTime.UtcNow.AddHours(1),
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature)
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

    }
}



