﻿namespace Final_proyecto.Models
{
    public class LoginRequest
    {
        
         public string email { get; set; }
         public string contrasena { get; set; }
        

    }
}
