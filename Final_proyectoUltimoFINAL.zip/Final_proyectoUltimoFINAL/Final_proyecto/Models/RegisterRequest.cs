﻿using System.ComponentModel.DataAnnotations;

namespace Final_proyecto.Models
{
    public class RegisterRequest
    {
        public string Email { get; set; }
        public string Contraseña { get; set; }
        public string CodigoVerificacion { get; set; }  // este lo compara el usuario
    }

}
